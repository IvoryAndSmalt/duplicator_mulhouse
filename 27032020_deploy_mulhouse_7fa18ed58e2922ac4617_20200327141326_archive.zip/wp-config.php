<?php
/**
* The base configuration for WordPress
*
* The wp-config.php creation script uses this file during the
* installation. You don't have to use the web site, you can
* copy this file to "wp-config.php" and fill in the values.
*
* This file contains the following configurations:
*
* * MySQL settings
* * Secret keys
* * Database table prefix
* * ABSPATH
*
* @link https://codex.wordpress.org/Editing_wp-config.php
*
* @package WordPress
*/
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );
/** MySQL database username */
define( 'DB_USER', '' );
/** MySQL database password */
define( 'DB_PASSWORD', '' );
/** MySQL hostname */
define( 'DB_HOST', '' );
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );
/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
/**#@+
* Authentication Unique Keys and Salts.
*
* Change these to different unique phrases!
* You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
* You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
*
* @since 2.6.0
*/
define( 'AUTH_KEY',         '$!DH4G~WIIqtK})J6*M$W4.OH3H:=,O3-tgY&-0v=%eX|{qB>a!h yZxzG>`=#|$' );
define( 'SECURE_AUTH_KEY',  '&J#wX=z,$UPB^)%fma7p.HVYPAe5Be|_p>b4B~qw?xWCbLXd@cec^a=Zm[4vC8C(' );
define( 'LOGGED_IN_KEY',    '&_Sd?U ;#Z,Tjd)#<4p_oW4~CORz,NzrU#aKpadXMli`>/`wD+n@EqF[fmVL/4*%' );
define( 'NONCE_KEY',        '4Dog,#M~ACGYP=gO<oUu?c8$~e#h_hD~D<z:r|oT&)ddh.9@MR%Q0(Y^%zO$q*T=' );
define( 'AUTH_SALT',        'nZ~@-x>~X`.AtkKy*lMlCS[y&2rcaL_yBd;Z<^Os+=iF{YToqY>^U.u8Si.ug>yz' );
define( 'SECURE_AUTH_SALT', 'a,o!U}`*q.U62L_dluOaKx1ToBpA]c[Ah9Q7cu3?*P(*%+l}wyY3TBQfq!vA-AZS' );
define( 'LOGGED_IN_SALT',   'mvDsGk3$I:}oF_x5@bQb_Vst7n>LLLPMwEh>=`ZKsKil;hh{~6l<5^7@(<*yV9b(' );
define( 'NONCE_SALT',       'TBR0<o9SWhA(;{Un(K;?sT6&=(R`MVi!ic&6C$E(_O=b[VXMY0!|/8aD]4bmAs_,' );
/**#@-*/
/**
* WordPress Database Table prefix.
*
* You can have multiple installations in one database if you give each
* a unique prefix. Only numbers, letters, and underscores please!
*/
$table_prefix = '58jf_';
/**
* For developers: WordPress debugging mode.
*
* Change this to true to enable the display of notices during development.
* It is strongly recommended that plugin and theme developers use WP_DEBUG
* in their development environments.
*
* For information on other constants that can be used for debugging,
* visit the Codex.
*
* @link https://codex.wordpress.org/Debugging_in_WordPress
*/
define( 'WP_DEBUG', false );
/* That's all, stop editing! Happy publishing. */
/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}
/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
